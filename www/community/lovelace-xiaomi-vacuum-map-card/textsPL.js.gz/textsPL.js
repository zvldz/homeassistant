const textMode = "Tryb";
const textGoToTarget = "Idź do punktu";
const textZonedCleanup = "Czyszczenie strefowe";
const textZones = "Strefy";
const textRun = "Uruchom";
const textRepeats = "Razy:";
const textRemoveLastZone = "Usuń ostatnią strefę";
const textRemoveAllZones = "Wyczyść";

export {
    textMode,
    textGoToTarget,
    textZonedCleanup,
    textZones,
    textRun,
    textRepeats,
    textRemoveLastZone,
    textRemoveAllZones
};