const textMode = "Mode";
const textGoToTarget = "Go to target";
const textZonedCleanup = "Zoned cleanup";
const textZones = "Zones";
const textRun = "Start";
const textRepeats = "Times:";
const textRemoveLastZone = "Remove last zone";
const textRemoveAllZones = "Remove all zones";

export {
    textMode,
    textGoToTarget,
    textZonedCleanup,
    textZones,
    textRun,
    textRepeats,
    textRemoveLastZone,
    textRemoveAllZones
};